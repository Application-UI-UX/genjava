This used to generate the gradle wrapper for a project. Simply untar it.
When creating the tarball, simply run the following command in any gradle projects root.

> tar -cvzf gradle.tar.gz gradlew gradle gradlew.bat gradle.properties
